# D&B Typeahead demo

This is a quick demo of a typeahead implementation done with the [D&B Direct+ API](https://directplus.documentation.dnb.com/)

## Usage

Change the 'this.host', 'this.port' and 'this.protocol' variables to your internal API proxy in the dnb.js file. This needs to be done to avaoid CORS errors. Please also see the dnb-api Repo for further details.

- Version: 0.0.5
- License: © by Bisnode.ch
